declare module "@salesforce/apex/FlexTemplateController.getFlexTemplateResponse" {
  export default function getFlexTemplateResponse(param: {AccName: any, rating: any}): Promise<any>;
}
